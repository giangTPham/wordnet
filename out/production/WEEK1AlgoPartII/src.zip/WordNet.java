
import edu.princeton.cs.algs4.Digraph;

import edu.princeton.cs.algs4.KosarajuSharirSCC;


import java.io.IOException;
import java.util.*;
//import java.nio.charset.StandardCharsets;
//import java.nio.file.Files;
//
//import java.nio.file.Paths;



public class WordNet {
    private List<String> synsetList;
    private Map<String, List<Integer>> synsetMap;
    private Digraph G;
    private SAP sapG;

    // constructor takes the name of the two input file
    public WordNet(String synsets, String hypernyms) {
        if (synsets == null || hypernyms == null) throw new IllegalArgumentException();
        synsetList = new ArrayList<>();
        synsetMap = new HashMap<>();

        Scanner strIn = new Scanner(synsets);
        while (strIn.hasNextLine()) {
            String strLine = strIn.nextLine();
            String[] tokens = strLine.split(",");
            int id = Integer.parseInt(tokens[0]);
            synsetList.add(tokens[1]);
            String[] nouns = tokens[1].split(" ");
            for (String noun: nouns) {
                synsetMap.put(noun, new ArrayList<Integer>());
                synsetMap.get(noun).add(id);
            }
        }

        G = new Digraph(synsetList.size());
        Scanner hypIn = new Scanner(hypernyms);
        int[] outputs = new int[synsetList.size()];
        while (hypIn.hasNextLine()) {
            String hypLine = hypIn.nextLine();
            String[] tokens = hypLine.split(",");
            int v = Integer.parseInt(tokens[0]);
            outputs[v] = tokens.length - 1;
            for (int i = 1; i < tokens.length; i++) {
                int w = Integer.parseInt(tokens[i]);
                G.addEdge(v, w);
            }
        }

        if (!checkRootedDigraph(outputs)) {
            throw new IllegalArgumentException();
        }

        sapG = new SAP(G);

    }

    private boolean checkRootedDigraph(int[] outputs) {
        int rootCount = 0;
        for (int v: outputs) {
            if (v == 0) rootCount++;
            if (rootCount > 1) return false;
        }
        if (new KosarajuSharirSCC(G).count() < synsetList.size()) {
            return false;
        }
        return true;
    }

    // returns all WordNet nouns
    public Iterable<String> nouns() {return synsetMap.keySet();}

    // is the word a WordNet noun?
    public boolean isNoun(String word) {return synsetMap.containsKey(word);}

    // distance between nounA and nounB (defined below)
    public int distance(String nounA, String nounB) {
        if (!isNoun(nounA) || !isNoun(nounB)) throw new IllegalArgumentException();
        return sapG.length(synsetMap.get(nounA), synsetMap.get(nounB));
    }

    // a synset (second field of synsets.txt) that is the common ancestor of nounA and nounB
    // in a shortest ancestral path (defined below)
    public String sap(String nounA, String nounB) {
        if (!isNoun(nounA) || !isNoun(nounB)) throw new IllegalArgumentException();
        int ancestor = sapG.ancestor(synsetMap.get(nounA), synsetMap.get(nounB));
        return synsetList.get(ancestor);
    }



    // do unit testing of this class
    public static void main(String[] args) {

//        String synsets = Files.readString(Paths.get("src/synsets.txt") , StandardCharsets.US_ASCII);
//        String hypernyms = Files.readString(Paths.get("src/hypernyms.txt") , StandardCharsets.US_ASCII);
//        WordNet wordNet = new WordNet(synsets, hypernyms);
//        for (String s: wordNet.nouns()) {
//            System.out.println(s);
//        }
//        System.out.println(wordNet.isNoun("numbertwelve"));
//        System.out.println(wordNet.distance("numberfive","numberone"));
//        System.out.println(wordNet.sap("numberfive", "numberone"));
    }
}
